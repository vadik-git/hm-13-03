﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ClassLibrary
{
    public class Service
    {

        public List<Curency> curencu = new List<Curency>();
        private double ReturnCourseDolar()
        {

           WebClient client = new WebClient();
           var xml = client.DownloadString("https://bank.gov.ua/NBUStatService/v1/statdirectory/exchange?date=");
           XDocument xdoc = XDocument.Parse(xml);
           var el = xdoc.Element("exchange").Elements("currency");
           var dollar_ua = el.Where(x => x.Element("r030").Value == "840").Select(x => x.Element("rate").Value).FirstOrDefault();
           double course = Convert.ToDouble(dollar_ua);



            return course;

           
        }

        private double ReturnCourseEuro()
        {
            WebClient client = new WebClient();
            var xml = client.DownloadString("https://bank.gov.ua/NBUStatService/v1/statdirectory/exchange?date=");
            XDocument xdoc = XDocument.Parse(xml);
            var el = xdoc.Element("exchange").Elements("currency");
            string euro_ua = el.Where(x => x.Element("r030").Value == "978").Select(x => x.Element("rate").Value).FirstOrDefault();
            double course = Convert.ToDouble(euro_ua);

            return course;
        }

        public void AddCurency()
        {
            Curency usd = new Curency() {
                Name = "USD",
                Course = ReturnCourseDolar()

            };
            Curency eur = new Curency()
            {
                Name = "EUR",
                Course = ReturnCourseEuro()

            };

            curencu.Add(usd);
            curencu.Add(eur);


        }


       


    }





}
