﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ClassLibrary;

namespace WpfCourse
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Service data = new Service();

        public MainWindow()
        {
          
            InitializeComponent();
            data.AddCurency();
            txt1.ItemsSource = data.curencu;
            Comboone.ItemsSource = data.curencu;
            Comboone.DisplayMemberPath = Name;
            ComboTwo.ItemsSource = data.curencu;
            ComboTwo.DisplayMemberPath = Name;



        }
        static int port = 8080;
        static string address = "127.0.0.1";


        public void CallServer()
        {
            try
            {
                IPEndPoint ipPoint = new IPEndPoint(IPAddress.Parse(address), port);

                EndPoint remoteIpPoint = new IPEndPoint(IPAddress.Any, 0);

                Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

                string message = "";


                Application.Current.Dispatcher.Invoke(() => {


                    message = $"{Comboone.Text} {ComboTwo.Text}";

                });

                byte[] data = Encoding.Unicode.GetBytes(message);
                socket.SendTo(data, ipPoint);

                int bytes = 0;

                data = new byte[1024];
                do
                {
                    bytes = socket.ReceiveFrom(data, ref remoteIpPoint);
                    string response = Encoding.Unicode.GetString(data, 0, bytes);
                    Application.Current.Dispatcher.Invoke(() => {


                        txt.Text = response;


                    });

                } while (socket.Available > 0);


                socket.Shutdown(SocketShutdown.Both);
                socket.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }


        }



        private void Button_Click(object sender, RoutedEventArgs e)
        {
           


            Task.Run(() => CallServer());
        }
    }
}
