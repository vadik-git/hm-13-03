﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using ClassLibrary;

namespace HM_13_03
{
     
    class Program
    {
    public static double Func(double one ,double two)
    {
        return one / two;
    }
       
       
        static int port = 8080;
        static void Main(string[] args)
        {
            Service dataS = new Service();

            // Console.WriteLine(ReturnCourseDolar());

            IPAddress iPAddress = IPAddress.Parse("127.0.0.1");
            IPEndPoint ipPoint = new IPEndPoint(iPAddress, port);


            EndPoint remoteEndPoint = new IPEndPoint(IPAddress.Any, 0);


            Socket listenSocket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            try
            {

                listenSocket.Bind(ipPoint);
                Console.WriteLine("Server started! Waiting for connection...");

                while (true)
                {
                    dataS.AddCurency();
                    double courseOne = 0;
                    double courseTwo = 0;
                    int bytes = 0;
                    byte[] data = new byte[1024];
                    bytes = listenSocket.ReceiveFrom(data, ref remoteEndPoint);

                    string msg = Encoding.Unicode.GetString(data, 0, bytes);

                    Console.WriteLine($"{DateTime.Now.ToShortTimeString()}:{msg} from {remoteEndPoint}");

                    string[] arr = msg.Split(' ');

                    foreach(var i in dataS.curencu)
                    {
                        if (i.Name == arr[0])
                        {
                            courseOne = i.Course;
                        }
                    }
                   foreach(var j in dataS.curencu)
                    {
                        if (j.Name == arr[1])
                        {
                            courseTwo = j.Course;
                        }
                    }


                    double answer = Func(courseOne, courseTwo);

                    string message = $" Your Course {answer}";
                    data = Encoding.Unicode.GetBytes(message);
                    listenSocket.SendTo(data, remoteEndPoint);






                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            





        }
    }
}
